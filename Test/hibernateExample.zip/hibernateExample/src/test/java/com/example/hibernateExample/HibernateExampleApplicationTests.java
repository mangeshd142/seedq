package com.example.hibernateExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
